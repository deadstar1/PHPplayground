<?php
define("UPLOAD_DIR", dirname(__FILE__) . "/../public/img");
